<?php
/**
 * 2022 Biller
 *
 * LICENSE PLACEHOLDER
 *
 * This source file is subject to the Apache License 2.0
 * that is bundled with this package in the file LICENSE.
 * It is also available through the world-wide-web at this URL:
 * http://www.apache.org/licenses/LICENSE-2.0.txt
 *
 * @author Biller <support@biller.com>
 * @copyright 2022 Biller
 * @license   http://www.apache.org/licenses/LICENSE-2.0.txt  Apache License 2.0
 */

namespace Biller\PrestaShop\Utility\Encryption\Contracts;

interface EncryptionInterface
{

    /**
     * Returns encrypted key
     *
     * @param string $key
     * @return string
     */
    public function encrypt($key);

    /**
     * Returns decrypted key
     *
     * @param $key
     * @return string
     */
    public function decrypt($key);
}
