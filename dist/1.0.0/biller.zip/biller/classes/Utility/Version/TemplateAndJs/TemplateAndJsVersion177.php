<?php
/**
 * 2022 Biller
 *
 * LICENSE PLACEHOLDER
 *
 * This source file is subject to the Apache License 2.0
 * that is bundled with this package in the file LICENSE.
 * It is also available through the world-wide-web at this URL:
 * http://www.apache.org/licenses/LICENSE-2.0.txt
 *
 * @author Biller <support@biller.com>
 * @copyright 2022 Biller
 * @license   http://www.apache.org/licenses/LICENSE-2.0.txt  Apache License 2.0
 */

namespace Biller\PrestaShop\Utility\Version\TemplateAndJs;

/**
 * Class TemplateAndJsVersion177. Used for getting template and js file names.
 * Used for versions from 1.7.7.0+.
 *
 * @package Biller\PrestaShop\Utility\TemplateAndJs\Redirection
 */
class TemplateAndJsVersion177 extends TemplateAndJsVersion17
{
    /**
     * @inheritDoc
     */
    public function getTabLinkTemplate()
    {
        return 'tab_link177.tpl';
    }

    /**
     * @inheritDoc
     */
    public function getOrderBillerSectionTemplate()
    {
        return 'order_biller_section177.tpl';
    }

    /**
     * @inheritDoc
     */
    public function getAddOrderSummaryTemplate()
    {
        return 'views/templates/admin/add_order_summary_177.tpl';
    }

    /**
     * @inheritDoc
     */
    public function getAddOrderSummaryJS()
    {
        return 'views/js/admin/addOrderSummary177.js';
    }
}
