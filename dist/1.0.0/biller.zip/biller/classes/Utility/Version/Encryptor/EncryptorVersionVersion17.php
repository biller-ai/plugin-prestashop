<?php
/**
 * 2022 Biller
 *
 * LICENSE PLACEHOLDER
 *
 * This source file is subject to the Apache License 2.0
 * that is bundled with this package in the file LICENSE.
 * It is also available through the world-wide-web at this URL:
 * http://www.apache.org/licenses/LICENSE-2.0.txt
 *
 * @author Biller <support@biller.com>
 * @copyright 2022 Biller
 * @license   http://www.apache.org/licenses/LICENSE-2.0.txt  Apache License 2.0
 */

namespace Biller\PrestaShop\Utility\Version\Encryptor;

use Biller\PrestaShop\Utility\Version\Encryptor\Contract\EncryptorVersionInterface;
use PhpEncryptionCore;

/**
 * Class EncryptorVersionVersion17. Used for encryption and decryption for PrestaShop 1.7+.
 *
 * @package Biller\PrestaShop\Utility\Version\Encryptor
 */
class EncryptorVersionVersion17 implements EncryptorVersionInterface
{
    /** @var PhpEncryptionCore $cipherTool */
    private $cipherTool;

    public function __construct()
    {
        $this->cipherTool = new PhpEncryptionCore(_NEW_COOKIE_KEY_);
    }

    /**
     * @inheritDoc
     */
    public function encrypt($key)
    {
        return $this->cipherTool->encrypt($key);
    }

    /**
     * @inheritDoc
     *
     * @throws \Exception
     */
    public function decrypt($key)
    {
        return $this->cipherTool->decrypt($key);
    }
}
