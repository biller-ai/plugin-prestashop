<?php
/**
 * 2022 Biller
 *
 * LICENSE PLACEHOLDER
 *
 * This source file is subject to the Apache License 2.0
 * that is bundled with this package in the file LICENSE.
 * It is also available through the world-wide-web at this URL:
 * http://www.apache.org/licenses/LICENSE-2.0.txt
 *
 * @author Biller <support@biller.com>
 * @copyright 2022 Biller
 * @license   http://www.apache.org/licenses/LICENSE-2.0.txt  Apache License 2.0
 */

namespace Biller\PrestaShop\Utility\Version\Redirection\Contract;

/**
 * Contains methods for redirection that vary by PrestaShop versions.
 */
interface RedirectionVersionInterface
{
    /**
     * Returns URL of order page.
     *
     * @param \Order $order
     *
     * @return string
     */
    public function generateOrderPageUrl($order);

    /**
     * Redirects back to checkout page.
     *
     * @return mixed
     */
    public function cancelRedirect();

    /**
     * Redirects back to checkout page with error message.
     *
     * @param string $message Message to be displayed
     *
     * @return mixed
     */
    public function errorRedirect($message);

    /**
     * Redirects back to checkout page after payment fail.
     *
     * @param string $message Message to be displayed
     *
     * @return mixed
     */
    public function paymentErrorRedirect($message);
}
