<?php
/**
 * 2022 Biller
 *
 * LICENSE PLACEHOLDER
 *
 * This source file is subject to the Apache License 2.0
 * that is bundled with this package in the file LICENSE.
 * It is also available through the world-wide-web at this URL:
 * http://www.apache.org/licenses/LICENSE-2.0.txt
 *
 * @author Biller <support@biller.com>
 * @copyright 2022 Biller
 * @license   http://www.apache.org/licenses/LICENSE-2.0.txt  Apache License 2.0
 */

namespace Biller\PrestaShop\Utility\Version\Redirection;

use PrestaShop\PrestaShop\Adapter\SymfonyContainer;

/**
 * Class RedirectionVersion177. Used for redirection and generating order page url.
 * Used for versions 1.7.7.0+.
 *
 * @package Biller\PrestaShop\Utility\Version\Redirection
 */
class RedirectionVersion177 extends RedirectionVersion17
{
    /**
     * @inheritDoc
     *
     * @throws \PrestaShopException
     * @throws \Exception
     */
    public function generateOrderPageUrl($order)
    {
        return SymfonyContainer::getInstance()->get('router')
            ->generate('admin_orders_view', ['orderId' => $order->id]);
    }
}
