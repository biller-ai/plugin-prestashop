/**
 * 2022 Biller
 *
 * LICENSE PLACEHOLDER
 *
 * This source file is subject to the Apache License 2.0
 * that is bundled with this package in the file LICENSE.
 * It is also available through the world-wide-web at this URL:
 * http://www.apache.org/licenses/LICENSE-2.0.txt
 *
 * @author Biller <support@biller.com>
 * @copyright 2022 Biller
 * @license   http://www.apache.org/licenses/LICENSE-2.0.txt  Apache License 2.0
 */

var Biller = Biller || {};

/**
 * Handles cancellation on button click.
 */
function cancelOrder(orderId) {
    const endpointURL = $('input[name="CANCEL_URL"]').val();

    Biller.ajaxService().post(endpointURL, {'orderId': orderId}, (response, status) => {
        location.reload();
    });
}

/**
 * Handles order capture on button click.
 */
function captureOrder(orderId) {
    const endpointURL = $('input[name="CAPTURE_URL"]').val();
    Biller.ajaxService().post(endpointURL, {'orderId': orderId}, (response, status) => {
        location.reload();
    });
}
