$(document).ready(function() {
    // hide activate module checkbox
    $('input[name="activateModule"]').parent('div').hide();
});