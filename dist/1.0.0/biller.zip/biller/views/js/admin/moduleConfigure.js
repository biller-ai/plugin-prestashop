/**
 * Hides activate module checkbox.
 */
$(document).ready(function() {
    $('input[name="activateModule"]').parent('div').hide();
});