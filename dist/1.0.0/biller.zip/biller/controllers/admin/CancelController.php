<?php
/**
 * 2022 Biller
 *
 * LICENSE PLACEHOLDER
 *
 * This source file is subject to the Apache License 2.0
 * that is bundled with this package in the file LICENSE.
 * It is also available through the world-wide-web at this URL:
 * http://www.apache.org/licenses/LICENSE-2.0.txt
 *
 * @author Biller <support@biller.com>
 * @copyright 2022 Biller
 * @license   http://www.apache.org/licenses/LICENSE-2.0.txt  Apache License 2.0
 */

use Biller\PrestaShop\Bootstrap;
use Biller\PrestaShop\Utility\Response;
use Biller\Infrastructure\ServiceRegister;
use Biller\Domain\Order\Status;
use Biller\Infrastructure\Logger\Logger;
use Biller\BusinessLogic\Integration\Order\OrderStatusTransitionService as OrderStatusTransitionServiceInterface;
use Biller\PrestaShop\BusinessService\OrderStatusTransitionService;
use Biller\PrestaShop\Utility\FlashBag;

/**
 * CancelController class. Used for handling order cancellation on order page.
 */
class CancelController extends ModuleAdminController
{
    /** @var string File name for translation contextualization */
    const FILE_NAME = 'CancelController';

    public function __construct()
    {
        parent::__construct();
        Bootstrap::init();

        $this->bootstrap = true;
    }

    /**
     * Handles ajax call for order cancellation. Try to change order history and trigger hookActionOrderStatusUpdate.
     *
     * @return void
     *
     * @throws PrestaShopDatabaseException
     * @throws PrestaShopException
     */
    public function displayAjaxCancelOrder()
    {
        $orderId = Tools::getValue('orderId');
        $order = new Order($orderId);
        try {
            $this->getOrderStatusTransitionService()->updateStatus(
                $order->id_cart,
                Status::fromString(Status::BILLER_STATUS_CANCELLED)
            );

            FlashBag::getInstance()->setMessage('success', 'Successful update.');

            Response::die200();
        } catch (Exception $exception) {
            Logger::logError($exception->getMessage());

            Response::die400(array('message' => $this->module->l(
                $exception->getMessage(),
                self::FILE_NAME
            )));
        }
    }

    /**
     * Returns order status transition service from service register.
     *
     * @return OrderStatusTransitionService
     */
    private function getOrderStatusTransitionService()
    {
        return ServiceRegister::getService(
            OrderStatusTransitionServiceInterface::class
        );
    }
}
